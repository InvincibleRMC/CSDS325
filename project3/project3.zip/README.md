# Project 3
To run server.py
```
python server.py
```

To run routers
```
python routers.py
```

Occasionally the UDP ports overlap if this happens restarting my computer seemed to fixed it.