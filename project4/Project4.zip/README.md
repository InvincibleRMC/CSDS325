# Project 4
To run Server
```
python server.py localhost 47590
```

To run client
```
export http_proxy=http://127.0.0.1:47590 && curl http://www.example.com/
```
Completed with Python 3.9