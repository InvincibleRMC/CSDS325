# Project 4
To run Server
```
python server.py localhost 47590
```

To run client
```
python client.py localhost 47590 http://www.example.com 
```
Completed with Python 3.9