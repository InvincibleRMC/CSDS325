# Project 4
To run Server
```
python server.py localhost 47590
```

To run client
```
python client.py localhost 47590 http://www.example.com 
```
Completed with Python 3.9

NOTE: Output looks different than result of wget but is still recieving info from HTTP server