# Project 1
To run Server
```
python server.py 50
```

To run clients
```
python client.py localhost 50
python client.py localhost 50
python client.py localhost 50
```
Completed with Python 3.9