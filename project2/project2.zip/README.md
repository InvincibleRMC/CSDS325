# Project 2
To run Reciever
```
python reciever.py 50 10
```

To run Sender
```
python sender.py localhost 50 10
```

Correctness Checker on Windows Powershell
```
diff (get-content download.txt) (get-content alice.txt)
```
Completed with Python 3.9